package uf5_pac3;

public interface IPersona extends Comparable <Persona>{


	// Getters
	public String getNombre();
	public String getApellidos();
	public String getDni();
	public int getEdad();
	public genero getGenero();
	
	// Setters
	public void setEdad (int edad);

	// Criterio de igualdad
	public boolean equals (Object obj);
	
	// Representacion cadena
	public String toString();
}
