package uf5_pac3;

import java.util.ArrayList;

public class Alumno extends Persona implements IAlumno {

	
	// 1.1 - Propiedades
	private String asignatura;
	private ArrayList<Float> notas;
	private float notaMedia;
	
	// 1.2 - Constructor
	public Alumno (String nombre, String apellidos, String dni, int edad, genero sexo, String asignatura) { 
		super(nombre, apellidos, dni, edad, sexo);
		this.asignatura=asignatura;
		notas=null;
	} 
		
	// 1.3 - Setters y getters:
	
	public String getAsignatura() {
		return asignatura;
	}

	public ArrayList<Float> getNotas() {
		return notas;
	}
	
	public float getNotaMedia(){
		float acumulador = 0;
		
		for (Float e : notas) {
			acumulador = acumulador + e;
		}
		notaMedia =acumulador/notas.size();
	return notaMedia;
	}
	
	
	public void setNotas (ArrayList<Float> lista_notas) {
		notas=lista_notas;
	}
	
	
	// 1.4 - Criterio de igualdad:
	
	public boolean equals (Object obj){
		boolean resultado = false;
		
		if (obj instanceof Alumno) {
			Alumno alu = (Alumno) obj;
		
			Integer this_Int = this.getEdad();
			Integer otro_Int = alu.getEdad();	
			
				if (this.getNombre().equals(alu.getNombre() ) &&  this_Int.equals(otro_Int)) {
					resultado=true;
				}
		}
		return resultado;
	}
	
	
	
	// 1.5 - Orden natural
	
	public int compareTo (Persona alu) {
		int resultado;
		
		Integer this_Int = this.getEdad();
		Integer otro_Int = alu.getEdad();
		
		resultado =this.getNombre().compareTo(alu.getNombre());
		if (resultado==0) {
			resultado=this_Int.compareTo(otro_Int);
		}
		
		return resultado;
	}


	
	// 1.6 - Representacion cadena
		public String toString(){
			return (super.getNombre() + ": " + this.getNotas());
		}
		
	// 1.7 y 1.8 - A�adir nota adicional a la lista con excepci�n
		@Override
		public void setNota_adicional (Float nota) {
			if (nota < 0 || nota > 10){
				throw new IllegalArgumentException("La nota debe ser un valor entre 0 y 10.");
			}
			else {notas.add(nota);}
		
		}
		
		
		
}
