package uf5_pac3;

public class Persona implements IPersona {

	// 1.1 - Propiedades:
	private String nombre;
	private String apellidos;
	private String dni;
	private int edad;
	private genero sexo;
	
	
	// 1.2 - Constructores:
	public Persona() { 
		nombre="";
		apellidos="";
		dni="";
		edad=0;
		sexo=genero.MUJER;
	} 
		
	public Persona(String nombre, String apellidos, String dni, int edad, genero sexo) { 
		this.nombre=nombre;
		this.apellidos=apellidos;
		this.dni=dni;
		this.edad=edad;
		this.sexo=sexo;
	} 
	
	
	
	// 1.3 - Setters y getters:
	@Override
	public String getNombre() {
		return nombre;
	}

	@Override
	public String getApellidos() {
		return apellidos;
	}

	@Override
	public String getDni() {
		return dni;
	}

	@Override
	public int getEdad() {
		return edad;
	}

	@Override
	public genero getGenero() {
		return sexo;
	}

	@Override
	// 1.7 - Excepci�n en el setter de la edad
	public void setEdad(int edad) {
		if (edad<0 || edad >110){
			throw new IllegalArgumentException("La edad debe ser un valor entre 0 y 110.");
		}
		else {this.edad=edad;}
	}

	// 1.4 - Criterio de igualdad

	public boolean equals (Object obj){
		boolean resultado = false;
		
		if (obj instanceof Persona) {
			Persona per = (Persona) obj;
		
			Integer this_Int = this.getEdad();
			Integer otro_Int = per.getEdad();
			
				if (this.getNombre().equals(per.getNombre() ) &&  this_Int.equals(otro_Int)) {
					resultado=true;
				}
		}
		return resultado;
	}
	
	
	
	
	// 1.5 - Orden natural - Comparable (compareTo())
	public int compareTo (Persona per) {
		int resultado;
		
		Integer this_Int = this.getEdad();
		Integer otro_Int = per.getEdad();
		
		resultado =this.getNombre().compareTo(per.getNombre());
		if (resultado==0) {
			resultado=this_Int.compareTo(otro_Int);
		}
		
		return resultado;
	}

	
	
	// 1.6 - Representacion cadena
	public String toString(){
		return this.getNombre() + " " + this.getApellidos() + " (" + this.getGenero() + ") con dni " + this.getDni() + " tiene " + this.getEdad() + " a�os.";
	}

	
}
