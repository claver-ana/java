package uf5_pac3;

public enum genero {
MUJER, HOMBRE
}
