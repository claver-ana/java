package uf5_pac3;

import java.util.ArrayList;

public class uso_persona_alumno {

	public uso_persona_alumno() {

	}

	public static void main(String[] args) {
		
		// CLASE PERSONA
		
		System.out.println("COMPROBACIONES DE LA CLASE PERSONA");
		
		// Comprobaci�n m�todo toString (que a la vez comprueba los getters)
		Persona p1 = new Persona ("Ana", "Claver Barcel�", "3884956H", 34, genero.MUJER);
		Persona p2 = new Persona ("Ana", "Bayarri Anaya", "2365956H", 24, genero.MUJER);
		Persona p3 = new Persona ("Ana", "Aguilar Domenech", "3859956A", 13, genero.MUJER);
		System.out.println("Persona 1: " + p1);
		System.out.println("Persona 2: " + p2);	
		System.out.println("Persona 3: " + p3);	
					
		// Comprobaci�n m�todo setEdad y imprimo para ver el cambio de edad
		p1.setEdad(13);
		System.out.println("Persona 1 (con edad nueva): " + p1);

		// Comprobaci�n m�todo getEdad trascambi
		System.out.println("Confirmado, la nueva edad es: "+p1.getEdad());
		
		// Comprobamos la funci�n de igualdad:
		System.out.println("\n" + p1.equals(p2) + " --> Quiere decir que Ana de 13 a�os (p1) es DISTINTO que Ana de 24 (p2)");
		System.out.println(p1.equals(p3) + " --> Quiere decir que Ana de 13 a�os (p1) es IGUAL que ANA de 13 (p3)");
		
				
		// Comprobamos la funci�n de orden natural - compareTo:
		System.out.println("\n" + p1.compareTo(p2) + " --> Quiere decir que Ana de 13 a�os (p1) es MENOR que Ana de 24 (p2)");
		System.out.println(p1.compareTo(p3) + " --> Quiere decir que Ana de 13 a�os (p1) es IGUAL que Ana de 13 (p3)");
		
		// Comprobamos la funci�n de orden natural - compare:
		comparacion_Personas compPersona = new comparacion_Personas();
		System.out.println("\n" + compPersona.compare(p1, p2) + " --> Quiere decir que Ana de 13 a�os (p1) es MENOR que Ana de 24 (p2)");
		System.out.println(compPersona.compare(p1, p3) + " --> Quiere decir que Ana de 13 a�os (p1) es IGUAL que Ana de 13 (p3)");


		
		// CLASE ALUMNO
		
		System.out.println("\nCOMPROBACIONES DE LA CLASE ALUMNO");
		
		// Creaci�n de 3 alumnos
		Alumno a1 = new Alumno ("Juan", "Dominguez Perez", "8569956C", 48, genero.HOMBRE,"Filosof�a");
		Alumno a2 = new Alumno ("Juan", "Rosales Vicente", "8856956H", 48, genero.HOMBRE,"Biolog�a");
		Alumno a3 = new Alumno ("Manolo", "Garcia Mendoza", "1258956B", 28, genero.HOMBRE,"Arquitectura");
				
		
		//Compruebo que la asignatura se pueda obtener con el get y tambi�n que las funciones de la superclase funcionen correctamente:
		System.out.println(a1.getNombre() + " "+a1.getApellidos() + " es un alumno que est� cursando " + a1.getAsignatura());

		
		// Le pasamos una lista de notas (funci�n setNotas()):
		ArrayList<Float> notas = new ArrayList<Float>();
		notas.add(new Float(3.5));
		notas.add(new Float(4.5));
		notas.add(new Float(8.5));
		a1.setNotas(notas);
		
		
		// Mostrar la lista de notas (funci�n getNotas()):
		System.out.println("La lista de notas de Juan es: " + a1.getNotas());
			
		// Mostrar la nota media (funci�n getNotaMedia()):
		System.out.println("Su nota media es de: " + a1.getNotaMedia());

		// A�adir notas adicionales:
		a1.setNota_adicional(1.5f);
		a1.setNota_adicional(1.5f);
		a1.setNota_adicional(1.5f);
		
		//ERROR PARA COMPROBAR LA EXCEPCI�N:
		//a1.setNota_adicional(11.5f);
		
		// Mostrar la lista de notas con las 3 nuevas notas:
		System.out.println("Le hemos a�adido 3 notas m�s, muy bajas: " + a1.getNotas());
					
		// Mostrar la nueva nota media: 
		System.out.println("Y ahora su media a bajado: " + a1.getNotaMedia());
		
		// Comprobamos la funci�n sobreescrita toString():
		System.out.println("Este es su profil --> " + a1);


		// Comprobamos la funci�n de igualdad:
		System.out.println("\n" + a1.equals(a2) + " --> Quiere decir que Juan de 48 a�os (a1) es IGUAL que Juan de 48 (a2)");
		System.out.println(a1.equals(a3) + " --> Quiere decir que Juan de 48 a�os (a1) es DISTINTO que Manolo de 28 (a3)");

		// Comprobamos la funci�n de orden natural:
		System.out.println("\n" + a1.compareTo(a2) + " --> Quiere decir que Juan de 48 a�os (a1) es IGUAL que Juan de 48 (a2)");
		System.out.println(a1.compareTo(a3) + " --> Quiere decir que Juan de 48 a�os (a1) es DISTINTO que Manolo de 28 (a3)");
	
		// Comprobamos la funci�n de orden natural - compare:
				comparacion_Personas compAlumno = new comparacion_Personas();
				System.out.println("\n" + compAlumno.compare(a1, a2) + " --> Quiere decir que Juan de 48 a�os (a1) es IGUAL que Juan de 48 (a2)");
				System.out.println(compAlumno.compare(a1, a3) + " --> Quiere decir que Juan de 48 a�os (a1) es DISTINTO que Manolo de 28 (a3)");

	}

}