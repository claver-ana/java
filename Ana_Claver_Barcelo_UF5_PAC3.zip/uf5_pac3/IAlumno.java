package uf5_pac3;

import java.util.ArrayList;

public interface IAlumno {
	
	// Getters y Setters
	public String getAsignatura();
	public ArrayList<Float> getNotas();
	public float getNotaMedia();
	public void setNotas (ArrayList<Float> lista_notas);
	
	
	// Criterio de igualdad
	public boolean equals (Object o);
		
	// Representacion cadena
	public String toString();
	
	// A�adir nota adicional (con excepci�n)
		void setNota_adicional(Float nota);
	
	
}
