package uf5_pac3;
import java.util.*;  

	// 1.5 - Orden natural - Comparator (compare()):

public class comparacion_Personas implements Comparator<Persona> {

	public int compare(Persona p1, Persona p2){  
		int resultado;

		Integer this_Int = p1.getEdad();
		Integer otro_Int = p2.getEdad();
		
			resultado= p1.getNombre().compareTo(p2.getNombre());
			
				if (resultado==0) {
					resultado=this_Int.compareTo(otro_Int);
				}
		
		return resultado;  
		}  
} 