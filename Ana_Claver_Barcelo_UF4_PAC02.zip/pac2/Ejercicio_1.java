package pac2;

public class Ejercicio_1 {

	public static void main (String [] args ){
	// Instancio la clase Finanzas
	Finanzas Finanza1 = new Finanzas();
	
	// llamada a los dos m�todos
	System.out.println(Finanza1.euros_a_dolares(50));
	System.out.println(Finanza1.dolares_a_euros(15));
	
	}
	
} 

