package pac2;

public class Ejercicio_2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// llamada al m�todo que devuelve el doble
		MiNumero Numero1 = new MiNumero(2);
		System.out.println(Numero1.doblar());
		System.out.println(Numero1.triplicar());
		System.out.println(Numero1.cuadrupliar());
		
		
	} 

} 

