package Pac03;

public interface ICalculadora {

	public double sumar();
	public double sumar (double numero);
	public double restar();
	public double getNum1();
	public double getNum2();
	public void setNum1(double numero);
	public void setNum2(double numero);
	
}
